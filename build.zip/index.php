<?php
$https = isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] === 'on');
$proxy = isset($_SERVER['HTTP_X_FORWARDED_PROTO']) ? $_SERVER['HTTP_X_FORWARDED_PROTO'] : null;

if (!$https && $proxy !== 'https') {
    $newUrl = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("HTTP/1.1 301 Moved Permanently");
    header('Location: ' . $newUrl);
    die();
}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="ie ie6"> <![endif]-->
<!--[if IE 7]>         <html class="ie ie7"> <![endif]-->
<!--[if IE 8]>         <html class="ie ie8"> <![endif]-->
<!--[if IE 9]>         <html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!--> <html>         <!--<![endif]-->
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" >
        <meta charset="UTF-8">
        <meta name="referrer" content="origin">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
        <noscript><meta http-equiv="X-Frame-Options" content="DENY" /></noscript>
        <title>Change My World Now</title>
        <style>
            @font-face {
                font-family: "CMWNJadeRegular";
                src: url("/fonts/cmwn.woff") format("woff");
            }
        </style>
        <!-- inject:reset -->
        <style>
/* http://meyerweb.com/eric/tools/css/reset/ 
 *    v2.0 | 20110126
 *       License: none (public domain)
 *       */

html, body, div, span, applet, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, img, ins, kbd, q, s, samp,
small, strike, strong, sub, sup, tt, var,
b, u, i, center,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td,
article, aside, canvas, details, embed, 
figure, figcaption, footer, header, hgroup, 
menu, nav, output, ruby, section, summary,
time, mark, audio, video {
    margin: 0;
    padding: 0;
    border: 0;
    font-size: 100%;
    font: inherit;
    vertical-align: baseline;
}
/* HTML5 display-role reset for older browsers */
article, aside, details, figcaption, figure, 
footer, header, hgroup, menu, nav, section {
    display: block;
}
body {
    line-height: 1;
}
ol, ul {
    list-style: none;
}
blockquote, q {
    quotes: none;
}
blockquote:before, blockquote:after,
q:before, q:after {
    content: '';
    content: none;
}
table {
    border-collapse: collapse;
    border-spacing: 0;
}

</style>
        <!-- endinject -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/humane-js/3.2.2/themes/flatty.min.css" crossorigin="anonymous">
        <!-- inject:style -->
        <style>
/**
 * app.scss
 * Contains all of the core styles for the platform. Any style added
 * to this file will be inlined into the primary index.html in order
 * to prevent a possible jarring flash of unstyled content.
 * because we are importing them here, functions.scss and
 * variables.scss share this property
 */
html {
  font-size: 15px; }

@font-face {
  font-family: "CMWNJadeRegular";
  src: url("/fonts/cmwn.woff") format("woff"); }

@media (max-width: 667px) {
  body {
    font-size: 12px;
    font-size: 2vmax; } }

@media (min-width: 1800px) {
  body {
    font-size: 18px; } }

h1, h2, h3 {
  font-family: "CMWNJadeRegular", Impact, Helvetica, Arial, sans-serif; }

#pageerror, #triggerederror {
  position: fixed;
  display: block;
  top: 0px;
  bottom: 0px;
  left: 0px;
  right: 0px;
  background-position: center;
  background-repeat: no-repeat;
  background-color: #fff;
  z-index: 2000;
  background-size: contain;
  border: 15px solid #fff; }
  #pageerror a, #triggerederror a {
    cursor: pointer;
    position: fixed;
    top: 0px;
    bottom: 0px;
    left: 0px;
    right: 0px; }
  #pageerror.error403, #triggerederror.error403 {
    background-image: url(/9ac485d3511395f9639f5a2e1f196568.png); }
  #pageerror.error404, #triggerederror.error404 {
    background-image: url(/1ed9cfdde9d71fd12b3229a883cbf0f7.png); }
  #pageerror.error500, #triggerederror.error500 {
    background-image: url(/051f3dbebfdfc0175c53a6df166188e9.png); }
    #pageerror.error500 a, #triggerederror.error500 a {
      bottom: 42vh; }
    #pageerror.error500 a.gohome, #triggerederror.error500 a.gohome {
      top: 58vh;
      bottom: 0px; }
  #pageerror.applicationerror, #triggerederror.applicationerror {
    background-image: url(/1a7c57584cccaa3ce38da0e8adb175ce.png); }

#pageerror {
  opacity: 0;
  background: url(/4a414614dd45fcdd0802f6e3c1610a23.png) #fff;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  -webkit-animation: fadein 1s;
          animation: fadein 1s;
  -webkit-animation-delay: 5s;
          animation-delay: 5s;
  -webkit-animation-iteration-count: 1;
          animation-iteration-count: 1;
  -webkit-animation-fill-mode: forwards;
          animation-fill-mode: forwards; }

@-webkit-keyframes fadein {
  from {
    opacity: 0; }
  to {
    opacity: 1; } }

@keyframes fadein {
  from {
    opacity: 0; }
  to {
    opacity: 1; } }

#cmwn-app {
  min-height: 100vh;
  overflow-x: hidden;
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; }
  #cmwn-app .sweater, #cmwn-app .global-header {
    background: #fff;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2); }
  #cmwn-app .sweater, #cmwn-app .sweater .content {
    padding: 0; }
  #cmwn-app .sweater, #cmwn-app .sweater .content {
    padding: 0; }
  #cmwn-app .sweater {
    max-width: 985px;
    position: relative;
    padding: 15px;
    margin: 0;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 30px; }
    #cmwn-app .sweater .content, #cmwn-app .sweater .sidebar {
      padding-bottom: 15px; }
  #cmwn-app .blocker {
    position: absolute;
    padding-top: 15px;
    margin-top: 5px;
    margin-left: auto;
    margin-right: auto;
    background: white;
    width: 100%;
    left: 0;
    z-index: 503; }
  #cmwn-app .layout {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    margin-bottom: 60px;
    -webkit-box-align: stretch;
    -webkit-align-items: stretch;
        -ms-flex-align: stretch;
            align-items: stretch; }
  #cmwn-app .content {
    -webkit-box-ordinal-group: 3;
    -webkit-order: 2;
        -ms-flex-order: 2;
            order: 2;
    -webkit-box-flex: 1;
    -webkit-flex-grow: 1;
        -ms-flex-positive: 1;
            flex-grow: 1;
    -webkit-flex-shrink: 1;
        -ms-flex-negative: 1;
            flex-shrink: 1;
    padding: 7.5px; }
  #cmwn-app .breadcrumb {
    padding: 7.5px 15px;
    background: #f5f5f5;
    border-radius: 4px;
    display: inline-block;
    margin: 7.5px 0;
    font-size: 12px;
    display: none; }
    #cmwn-app .breadcrumb a + a::before, #cmwn-app .breadcrumb a + span::before {
      content: " | "; }
  #cmwn-app a {
    cursor: pointer; }
  #cmwn-app img {
    user-drag: none; }
  #cmwn-app .sidebar {
    -webkit-box-ordinal-group: 2;
    -webkit-order: 1;
        -ms-flex-order: 1;
            order: 1;
    -webkit-box-flex: 0;
    -webkit-flex-grow: 0;
        -ms-flex-positive: 0;
            flex-grow: 0;
    -webkit-flex-shrink: 0;
        -ms-flex-negative: 0;
            flex-shrink: 0;
    padding: 7.5px; }
    #cmwn-app .sidebar nav * {
      margin: 7.5px 0; }
    #cmwn-app .sidebar nav li:first-child {
      border-top: 1px solid #54c2f2; }
    #cmwn-app .sidebar nav li {
      border-bottom: 1px solid #54c2f2;
      padding: 7.5px; }
      #cmwn-app .sidebar nav li a {
        text-decoration: none;
        color: #54c2f2;
        font-weight: bold; }
  #cmwn-app .profile-pic {
    display: inline-block;
    overflow: hidden;
    width: 0;
    height: 172px;
    padding-left: 172px;
    color: transparent;
    background-size: cover; }
  #cmwn-app .global-header {
    position: relative;
    z-index: 501;
    max-width: 985px;
    height: 115px; }
  #cmwn-app .global-footer {
    -webkit-box-ordinal-group: 667;
    -webkit-order: 666;
        -ms-flex-order: 666;
            order: 666;
    width: 100%;
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 15px;
    border-top: 5px solid #2CC4F4; }
    #cmwn-app .global-footer .links a,
    #cmwn-app .global-footer .links a:active,
    #cmwn-app .global-footer .links a:visited {
      font-size: 13px;
      color: #000; }
    #cmwn-app .global-footer .links a:not(:last-child) {
      margin-right: 5px;
      padding-right: 5px;
      border-right: solid 1px #000; }
  #cmwn-app .logo-pad {
    margin-top: -15px;
    visibility: hidden;
    width: 100%; }
  #cmwn-app .logo, #cmwn-app .headerLogo {
    z-index: 504;
    display: inline-block;
    color: transparent;
    max-width: 900px; }
    #cmwn-app .logo a, #cmwn-app .headerLogo a {
      color: transparent; }
    #cmwn-app .logo .read, #cmwn-app .headerLogo .read {
      width: 0px; }
  #cmwn-app .logo img {
    width: 165px; }
  #cmwn-app .headerLogo {
    float: right;
    padding-right: 10px;
    width: calc(100% - 70px - 165px);
    padding: 15px 80px 0 35px; }
    #cmwn-app .headerLogo img {
      width: 100%; }
  #cmwn-app .menu, #cmwn-app .logout {
    position: absolute;
    color: transparent;
    right: 0;
    top: 0;
    background-size: contain; }
    #cmwn-app .menu a, #cmwn-app .logout a {
      color: transparent; }
    #cmwn-app .menu a span, #cmwn-app .logout a span {
      position: absolute; }
    #cmwn-app .menu a img, #cmwn-app .logout a img {
      width: 70px; }
  #cmwn-app .menu {
    display: none;
    padding: 7.5px;
    width: 62.5px;
    height: 62.5px;
    border: 0; }
    #cmwn-app .menu .glyphicon {
      color: #000;
      font-size: 3em; }
    #cmwn-app .menu .fallback {
      display: inline-block;
      width: 0; }
  #cmwn-app .current-user-info {
    position: absolute;
    bottom: 15px;
    right: 15px;
    font-size: 0.7rem; }
  #cmwn-app section h3 {
    background: url(data:image/jpeg;base64,/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP/sABFEdWNreQABAAQAAAAyAAD/4QMsaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjUtYzAyMSA3OS4xNTQ5MTEsIDIwMTMvMTAvMjktMTE6NDc6MTYgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDQyAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo5NDhENUYwNEI0MDExMUU0ODc5QzgwNzBFMkI0ODlBRCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo5NDhENUYwNUI0MDExMUU0ODc5QzgwNzBFMkI0ODlBRCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjk0OEQ1RjAyQjQwMTExRTQ4NzlDODA3MEUyQjQ4OUFEIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjk0OEQ1RjAzQjQwMTExRTQ4NzlDODA3MEUyQjQ4OUFEIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+/+4ADkFkb2JlAGTAAAAAAf/bAIQACAYGBgYGCAYGCAwIBwgMDgoICAoOEA0NDg0NEBEMDg0NDgwRDxITFBMSDxgYGhoYGCMiIiIjJycnJycnJycnJwEJCAgJCgkLCQkLDgsNCw4RDg4ODhETDQ0ODQ0TGBEPDw8PERgWFxQUFBcWGhoYGBoaISEgISEnJycnJycnJycn/8AAEQgAJwJYAwEiAAIRAQMRAf/EAHYAAQEBAQEBAAAAAAAAAAAAAAABAgMEBgEBAQEBAQAAAAAAAAAAAAAAAAECBgMQAAIBAwMDAwQCAgMAAAAAAAABESExAkHRElGSA2FxIpEychOBQrGCUmIjEQEAAgMBAQADAAAAAAAAAAAAYSKhYiMBETFxEv/aAAwDAQACEQMRAD8A+kSU1+0z9zl2Rp29ehlxTFXOqcQ1j1y1CUS3qKTEe4fyT0SICV+rIksbK5VVEp7ooO/+RDqpM5OE3f1Lg08Z16gVKKEyxU8k/wCCu/uasgOVy0mE6lyTq8dSRljdV1ANpOuhMurHHJquoyxVE6sCTytoWPl8nJnJ6KnUzyirKrrOhjN0ZzWTmruXLKkN1Hw+OcuqWl/UrTolRMzxXKtPUqxcz9DSkcPoZyyxxSmZevuaajSpG4Vq6AZaSpfqjeN6aGVi8fVs3i8k4ahdR6GT8q8mLwS4f3NOb6ll6idWQYab+TM5YZZY0cPqjq05qYhcmk6K7KMw4IsZnJ30NtUbt0MUcpu1gDwyieUBRkafFtJv3DhW9mBF1yctWMuFLmfQuTySSxU9SOG4x0uVWUpc/RETXKWa4vJuFHQZYJYWqqwAyUYy38tDLSxXLN10Lj/6PFPGGlboEm8k8lMOgEj48irGFC11dzbjJtqnVCKpO3UfRzXhafy9zeOKxycKhYcqttDSxTrlbQfRE4lPWzNLxLCclfK5rimjWOKSq/Yz9T6cJhJ30K1RVKk4bemoVcZxrLoRBS1CcM1xs4l6msfG3NIZ0WPG7lk99T654YJ5LLLSx11qvYqUJTc0q01J76n1mKpaGkq39goszSUUZERTpYOlCp6P+BDtoQXH1savUyuiNaRYA/YqQBECgAAAAAAAAAAAAAAAAAAAAAAHjax/rcRGM/2L8oLeuhtpmGvcNJL/ACXWVZEvVAZUV42MtxbQ2vQSoc60kqueccVNJMfJyk4R1zxnGlzl9qdY0ZfF8dfFmn8dVqbvVnLxr+ycnV9Ce/lPWVjn+xt5Tg/tWpajL5JomGH68eCby9XcgrM5K5tqfQZKUB5nWn1M/c6Hd4S/e5j9bVqQa+r9c4ZI6/Q68WR41ll+n1hWnVaE+Tqro1DmTOVninXVhUTbUuqJlKq16lUvW2gyjJ0r6FEUtqbaDi8ru2jIkuNKPoXg4jTVgLQptc1RqtkRrSINYpu/9QExarMcUq6XZtJ5NTroXjeuxBiUlCqhxczEplSimuhpWjUDHGL0bDTiCwmnL/kiVPV2TKM5SqDhEJajNcazoMWpTm95AjTxabyldNSw4nFlXGrf1RKUlUTCo+KU43epE5+51NNf2irsXFZXj3YDL4x8f5Hxyf21RpY5Os3ENJy6qwQidIfUuKeVrIioqXuaWLv9UQWJ1qbxSahKWTFYJe1jpjRJqnqT1FXjTo38YqiYcPClbHA038VSrGWGGeKxySyxfUn7R0UWm4SVKSZwxx8aWClxqzabj1MouNXPQ1ipbcBKnRalh20IhCdSw+g9JLeiAiVfUtbMsChBEupUChERQAAAAAAAAAAAAAAAAAAAAAAAAAPM8HenquS3Lxy46fVbgFtD157Jwa1x9fktyfrd5x9FyW4AvBz2wcJu0l+S3C8fV4x+S3AF4KbYODm6j8luR4YvKXx7sdwBeCmxw+VIn8lua4O9PbktwBaDnsiwyf8AxX+y3Lwyi67luALQc9sHBxdfVbjg4q8e5bgC0HPbBwfXHuW5OD6ruW4AtBTbDP631x7luZ/Xqnj3LcAt4Wm2GMvG6tvGfyW5j9T64+3LHcAt4Wm2Ey8TpXH+MluP1REPF/7LcAt4KbK/G19rxn8sdw/FnRrLH25Y7gC8FNsNfrpVqdfljuaXi/7Y+vyx3AJeEptg/V1yx7sdzD8daPGPyW4A8/uCm2BYP07luT9dbqfyW4BbQtNmcsJUPisdHyW5lePq8Z/JbgFtC02V4ZN6L3yW5F421D4+/LHcAWgpsq8VF8sY6cluV+N6vHuW4AvCU2wLxtXajT5KP8kfjy6ruW4AvBTbDa8bbSbXo+S3K8HanvyW4BLQU2THDLR4x+S3NLBzNJ/JbgC0FNnTHBqr4tvTljuaWDaTfFenLHcAzeE57YaWPkbbolZKUXHDNzVJK1VUAloTnthpePJy5xVbcluaWDq3HtyW4BLQnPbC4+NxVr0+S3OnBxEr35LcAnv9wc9sLw9u5bjg4uu5bgEvCc9sHB+nctxwy6ruW4AvBz2wvDLqu5bjg+q7luALwc9sHB9V3LccH1XctwBeDntg4Pqu5bjg+q7luALwc9sHB9V3LccH1XctwBeDntg4Pqu5bjg+q7luALwc9sHB9V3LccH1XctwBeDntg4Pqu5bjg+q7luALwc9sHB9V3LccH1XctwBeDntg4Pqu5bjg+q7luALwc9sHB9V3LccH1XctwBeDntg4Pqu5bgAXg57Yf/Z);
    background-color: #2CC4F4;
    background-size: 100% auto;
    padding: 7.5px 15px;
    color: #FFF;
    text-transform: uppercase; }
  #cmwn-app h1, #cmwn-app h2, #cmwn-app h3 {
    font-family: "CMWNJadeRegular", Impact, Helvetica, Arial, sans-serif;
    -webkit-filter: blur(0);
            filter: blur(0);
    -webkit-font-smoothing: antialiased; }
  #cmwn-app h1 {
    font-size: 2rem; }
  #cmwn-app h2 {
    font-size: 1.7rem; }
  #cmwn-app h3 {
    font-size: 1.5rem; }
  #cmwn-app .right {
    float: right; }
  #cmwn-app .left {
    float: left; }
  #cmwn-app .clear {
    clear: both; }
  @media (max-width: 667px) {
    #cmwn-app {
      font-size: 12px; }
      #cmwn-app .sweater {
        width: 100%;
        margin: 0;
        padding: 0; }
      #cmwn-app .layout {
        padding-bottom: 60px; }
      #cmwn-app .blocker {
        display: none; }
      #cmwn-app .menu {
        display: block; }
      #cmwn-app .logout {
        display: none; }
      #cmwn-app .headerLogo {
        padding: 0;
        margin: 25px 70px 0 0; }
      #cmwn-app .content {
        padding: 0; }
      #cmwn-app h1, #cmwn-app h2, #cmwn-app h3, #cmwn-app h4, #cmwn-app h5, #cmwn-app .breadcrumb {
        margin-left: 15px; }
      #cmwn-app .current-user-info {
        display: none; }
      #cmwn-app .sidebar {
        padding: 15px;
        background: #fff;
        position: fixed;
        top: 0;
        bottom: 0;
        right: -110%;
        width: 100%;
        overflow-y: scroll;
        -webkit-transition: right  1s ease-in-out;
        transition: right  1s ease-in-out;
        min-height: 100vh;
        z-index: 500; }
        #cmwn-app .sidebar.open {
          right: 0; }
      #cmwn-app .flip.fill {
        max-width: 100%; }
        #cmwn-app .flip.fill img, #cmwn-app .flip.fill object, #cmwn-app .flip.fill .item, #cmwn-app .flip.fill .overlay {
          max-width: 100%; } }
  @media (min-width: 985px) {
    #cmwn-app .global-header {
      padding: 0 15px;
      position: relative;
      margin-left: auto;
      margin-right: auto; } }
  @media (min-width: 985px) {
    #cmwn-app .logo {
      margin-left: calc(((985px - (100 * 1vw)) / 2) + 10px); } }
  @media (min-width: 1149px) {
    #cmwn-app .logo {
      margin-left: -82px; } }

html.ie9 #pageerror {
  display: none; }

html.ie9 #cmwn-app h1, html.ie9 #cmwn-app h2, html.ie9 #cmwn-app h3, html.ie9 #cmwn-app h4, html.ie9 #cmwn-app span, html.ie9 #cmwn-app p, html.ie9 #cmwn-app li, html.ie9 #cmwn-app td {
  filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBNYWNpbnRvc2giIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6OTJBQkFGRUZFOTIyMTFFMEJDRDNEQzkxOTVGOTNBODAiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6OTJBQkFGRjBFOTIyMTFFMEJDRDNEQzkxOTVGOTNBODAiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo5MkFCQUZFREU5MjIxMUUwQkNEM0RDOTE5NUY5M0E4MCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo5MkFCQUZFRUU5MjIxMUUwQkNEM0RDOTE5NUY5M0E4MCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PtrV+I8AAAAQSURBVHjaYvj//z8DQIABAAj8Av7bok0WAAAAAElFTkSuQmCC',sizingMethod=crop);
  zoom: 1; }

html.ie9 #cmwn-app .layout {
  display: table;
  width: 100%; }

html.ie9 #cmwn-app .content {
  display: table-cell;
  width: 100%; }

</style>
        <!-- endinject -->
        <!--[if IE]>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/xdomain/0.7.3/xdomain.min.js" crossorigin="anonymous"></script>
            <script>
                xdomain.debug = true;
                xdomain.slaves({
                    'https://*.changemyworldnow.com': '/proxy.html',
                    'https://papi.changemyworldnow.com': '/proxy.html',
                    'https://changemyworldnow.com': '/proxy.html'
                });
            </script>
        <![endif]-->
        <!-- inject:env -->
        <script>
window.__cmwn = {};
window.__cmwn.MODE = "local";
window.__cmwn.VERSION = "0.2.29";
</script>
        <!-- endinject -->
        <?php
            echo "<script>\n";
            echo "window.__cmwn = window.__cmwn || {};\n";
            foreach ($_SERVER as $key=>$val) {
                if (strrpos($key, "APP_", -strlen($key)) !== FALSE) {
                    echo 'window.__cmwn.'.substr($key, 4)." = '".str_replace('_', '.', $val)."';\n";
                }
            }
            $package = file_get_contents('./package.json');
            $packageJSON = json_decode($package, true);
            echo "window.__cmwn.VERSION = '".$packageJSON['version']."';\n";
            echo "</script>";
         ?>
    </head>
    <body>
        <div id="pageerror"><a href="/login"> </a></div>
        <div id="cmwn-app"></div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/babel-polyfill/6.3.14/polyfill.min.js" crossorigin="anonymous"></script>
        <!--[if lte IE 9]>
            <script>
            (function(){
            var ef = function(){};
            window.console = window.console || {log:ef,warn:ef,error:ef,dir:ef};
            }());
            </script>
            <script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.2/html5shiv-printshiv.min.js"></script>
            <script src="//cdnjs.cloudflare.com/ajax/libs/es5-shim/3.4.0/es5-shim.js"></script>
            <script src="//cdnjs.cloudflare.com/ajax/libs/es5-shim/3.4.0/es5-sham.js"></script>
        <![endif]-->
        <!--[if IE]>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/flexie/1.0.3/flexie.min.js"></script>
        <![endif]-->
        <script type="text/javascript">
            var isIE10 = false;
            var fileref;
            /*@cc_on
                if (/^10/.test(@_jscript_version)) {
                    isIE10 = true;
                }
            @*/
            if (!(window.ActiveXObject) && "ActiveXObject" in window && navigator.userAgent.match(/Trident.*rv[ :]*11\./)) {
                document.getElementsByTagName('html')[0].className += ' ie ie11';
            }
            if (isIE10){
                document.getElementsByTagName('html')[0].className += ' ie ie10';
                fileref=document.createElement('script');
                fileref.setAttribute("type","text/javascript");
                fileref.setAttribute("src", "https://cdnjs.cloudflare.com/ajax/libs/xdomain/0.7.3/xdomain.min.js");
                document.head.appendChild(fileref);
            }
            //polyfill localstorage
            if (window.localStorage == null) {
                fileref=document.createElement('script');
                fileref.setAttribute("type","text/javascript");
                fileref.setAttribute("src", "//cdnjs.cloudflare.com/ajax/libs/localStorage/2.0.1/localStorage.min.js");
                document.head.appendChild(fileref);
            }
            try {
                //will fail in private safari
                window.localStorage.setItem('testKey', '1');
                window.localStorage.removeItem('testKey');
            } catch (error) {
                //we dont rely on localstorage as a source of truth
                //so we can safely ignore these errors
                Storage.prototype._setItem = Storage.prototype.setItem;
                Storage.prototype.setItem = function() {};
            }
        </script>
        <script>
            var style = document.createElement('style');
            style.appendChild(document.createTextNode(''));
            document.head.appendChild(style);
            if (document.styleSheets[0].addRule != null){
                style.sheet.addRule('#pageerror', 'display:none;', 0);
            } else if (document.styleSheets[0].insertRule != null) {
                style.sheet.insertRule('#pageerror{display:none;}', 0);
            }
        </script>
        <!-- rollbar -->
        <script>
        var _rollbarConfig = {
            accessToken: "4635aacc2d3645a48e99c947e3a75a8d",
            captureUncaught: true,
            payload: {
                environment: __cmwn.MODE,
                client: {
                  javascript: {
                    source_map_enabled: true,
                    code_version: __cmwn.VERSION,
                    // Optionally have Rollbar guess which frames the error was thrown from
                    // when the browser does not provide line and column numbers.
                    guess_uncaught_frames: true
                  }
                }
            }
        };
        ;
        // Rollbar Snippet
        !function(r){function o(e){if(t[e])return t[e].exports;var n=t[e]={exports:{},id:e,loaded:!1};return r[e].call(n.exports,n,n.exports,o),n.loaded=!0,n.exports}var t={};return o.m=r,o.c=t,o.p="",o(0)}([function(r,o,t){"use strict";var e=t(1).Rollbar,n=t(2);_rollbarConfig.rollbarJsUrl=_rollbarConfig.rollbarJsUrl||"https://d37gvrvc0wt4s1.cloudfront.net/js/v1.8/rollbar.min.js";var a=e.init(window,_rollbarConfig),i=n(a,_rollbarConfig);a.loadFull(window,document,!_rollbarConfig.async,_rollbarConfig,i)},function(r,o){"use strict";function t(r){return function(){try{return r.apply(this,arguments)}catch(o){try{console.error("[Rollbar]: Internal error",o)}catch(t){}}}}function e(r,o,t){window._rollbarWrappedError&&(t[4]||(t[4]=window._rollbarWrappedError),t[5]||(t[5]=window._rollbarWrappedError._rollbarContext),window._rollbarWrappedError=null),r.uncaughtError.apply(r,t),o&&o.apply(window,t)}function n(r){var o=function(){var o=Array.prototype.slice.call(arguments,0);e(r,r._rollbarOldOnError,o)};return o.belongsToShim=!0,o}function a(r){this.shimId=++s,this.notifier=null,this.parentShim=r,this._rollbarOldOnError=null}function i(r){var o=a;return t(function(){if(this.notifier)return this.notifier[r].apply(this.notifier,arguments);var t=this,e="scope"===r;e&&(t=new o(this));var n=Array.prototype.slice.call(arguments,0),a={shim:t,method:r,args:n,ts:new Date};return window._rollbarShimQueue.push(a),e?t:void 0})}function l(r,o){if(o.hasOwnProperty&&o.hasOwnProperty("addEventListener")){var t=o.addEventListener;o.addEventListener=function(o,e,n){t.call(this,o,r.wrap(e),n)};var e=o.removeEventListener;o.removeEventListener=function(r,o,t){e.call(this,r,o&&o._wrapped?o._wrapped:o,t)}}}var s=0;a.init=function(r,o){var e=o.globalAlias||"Rollbar";if("object"==typeof r[e])return r[e];r._rollbarShimQueue=[],r._rollbarWrappedError=null,o=o||{};var i=new a;return t(function(){if(i.configure(o),o.captureUncaught){i._rollbarOldOnError=r.onerror,r.onerror=n(i);var t,a,s="EventTarget,Window,Node,ApplicationCache,AudioTrackList,ChannelMergerNode,CryptoOperation,EventSource,FileReader,HTMLUnknownElement,IDBDatabase,IDBRequest,IDBTransaction,KeyOperation,MediaController,MessagePort,ModalWindow,Notification,SVGElementInstance,Screen,TextTrack,TextTrackCue,TextTrackList,WebSocket,WebSocketWorker,Worker,XMLHttpRequest,XMLHttpRequestEventTarget,XMLHttpRequestUpload".split(",");for(t=0;t<s.length;++t)a=s[t],r[a]&&r[a].prototype&&l(i,r[a].prototype)}return r[e]=i,i})()},a.prototype.loadFull=function(r,o,e,n,a){var i=function(){var o;if(void 0===r._rollbarPayloadQueue){var t,e,n,i;for(o=new Error("rollbar.js did not load");t=r._rollbarShimQueue.shift();)for(n=t.args,i=0;i<n.length;++i)if(e=n[i],"function"==typeof e){e(o);break}}"function"==typeof a&&a(o)},l=!1,s=o.createElement("script"),u=o.getElementsByTagName("script")[0],p=u.parentNode;s.crossOrigin="",s.src=n.rollbarJsUrl,s.async=!e,s.onload=s.onreadystatechange=t(function(){if(!(l||this.readyState&&"loaded"!==this.readyState&&"complete"!==this.readyState)){s.onload=s.onreadystatechange=null;try{p.removeChild(s)}catch(r){}l=!0,i()}}),p.insertBefore(s,u)},a.prototype.wrap=function(r,o){try{var t;if(t="function"==typeof o?o:function(){return o||{}},"function"!=typeof r)return r;if(r._isWrap)return r;if(!r._wrapped){r._wrapped=function(){try{return r.apply(this,arguments)}catch(o){throw o._rollbarContext=t()||{},o._rollbarContext._wrappedSource=r.toString(),window._rollbarWrappedError=o,o}},r._wrapped._isWrap=!0;for(var e in r)r.hasOwnProperty(e)&&(r._wrapped[e]=r[e])}return r._wrapped}catch(n){return r}};for(var u="log,debug,info,warn,warning,error,critical,global,configure,scope,uncaughtError".split(","),p=0;p<u.length;++p)a.prototype[u[p]]=i(u[p]);r.exports={Rollbar:a,_rollbarWindowOnError:e}},function(r,o){"use strict";r.exports=function(r,o){return function(t){if(!t&&!window._rollbarInitialized){var e=window.RollbarNotifier,n=o||{},a=n.globalAlias||"Rollbar",i=window.Rollbar.init(n,r);i._processShimQueue(window._rollbarShimQueue||[]),window[a]=i,window._rollbarInitialized=!0,e.processPayloads()}}}}]);
        // End Rollbar Snippet
        </script>
        <!-- app:js -->
        <script src="/cmwn-0.2.29.js"></script>
        <!-- endinject -->
        <script src='https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit' async defer></script>
        <script>
          (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
          (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
          m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
          })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

          ga('create', 'UA-26000499-1', 'auto');
          ga('require', 'linkid');
          ga('require', 'displayfeatures');
          ga('send', 'pageview');

        </script>
    </body>
</html>
